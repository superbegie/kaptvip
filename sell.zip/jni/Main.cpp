// --- C Standard ---
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <math.h>
#include <limits>
#include <thread>
#include <vector>
#include <fstream>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/system_properties.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <xdl.h>
#include <SubstrateHook.h>
#include <CydiaSubstrate.h>
#include <KittyMemory/KittyMemory.h>
#include <KittyMemory/MemoryPatch.h>
#include <KittyMemory/KittyScanner.h>
#include <KittyMemory/KittyUtils.h>
#include <KittyUtils.h>
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"
#include "include/Theme.h"
#include "imgui/Font.h"
#include "imgui/Roboto-Regular.h"
#include "QQInj.h"
#include "AutoUpdate/IL2CppSDKGenerator/Il2Cpp.h"
#include "AutoUpdate/Tools/Call_Tools.h"
#include "Zygisk.hpp"
#include "Struct/DrawESP.h"
#include "Struct/class.h"

inline static int g_GlHeight, g_GlWidth;
inline static bool g_IsSetup = false;
inline int prevWidth, prevHeight;

using zygisk::Api;
using zygisk::AppSpecializeArgs;
using zygisk::ServerSpecializeArgs;

char packageName[] = "com.mobile.legends:UnityKillsMe";

void hack();

class MyModule : public zygisk::ModuleBase {
public:
    void onLoad(Api *api, JNIEnv *env) override {
        this->api_ = api;
        this->env_ = env;
    }

    void preAppSpecialize(AppSpecializeArgs *args) override {
        const char *process = env_->GetStringUTFChars(args->nice_name, nullptr);
        is_game_ = (strcmp(process, packageName) == 0);
        env_->ReleaseStringUTFChars(args->nice_name, process);
    }

    void postAppSpecialize(const AppSpecializeArgs *args) override {
        if (is_game_) {
            std::thread{hack}.detach();
        }
    }

private:
    Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
    bool is_game_ = false;
};
uintptr_t il2cpp_base = 0;
void *getRealAddr(ulong offset) {
  return reinterpret_cast<void*>(il2cpp_base + offset);
}
void SetupImgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui_ImplAndroid_Init(nullptr);

    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;

    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    // Warna dasar premium
    colors[ImGuiCol_Text]                  = ImVec4(0.92f, 0.92f, 0.95f, 1.00f);
    colors[ImGuiCol_TextDisabled]          = ImVec4(0.50f, 0.50f, 0.55f, 1.00f);
    colors[ImGuiCol_WindowBg]              = ImVec4(0.05f, 0.05f, 0.07f, 0.94f);
    colors[ImGuiCol_ChildBg]               = ImVec4(0.08f, 0.08f, 0.11f, 0.90f);
    colors[ImGuiCol_PopupBg]               = ImVec4(0.06f, 0.06f, 0.08f, 0.96f);
    colors[ImGuiCol_Border]                = ImVec4(0.30f, 0.25f, 0.45f, 0.80f);
    colors[ImGuiCol_FrameBg]               = ImVec4(0.12f, 0.10f, 0.16f, 1.00f);
    colors[ImGuiCol_FrameBgHovered]        = ImVec4(0.28f, 0.22f, 0.40f, 1.00f);
    colors[ImGuiCol_FrameBgActive]         = ImVec4(0.40f, 0.30f, 0.55f, 1.00f);
    colors[ImGuiCol_TitleBg]               = ImVec4(0.07f, 0.06f, 0.10f, 1.00f);
    colors[ImGuiCol_TitleBgActive]         = ImVec4(0.10f, 0.08f, 0.14f, 1.00f);
    colors[ImGuiCol_CheckMark]             = ImVec4(0.85f, 0.70f, 0.20f, 1.00f); // emas
    colors[ImGuiCol_SliderGrab]            = ImVec4(0.85f, 0.70f, 0.20f, 1.00f);
    colors[ImGuiCol_Button]                = ImVec4(0.18f, 0.14f, 0.26f, 1.00f);
    colors[ImGuiCol_ButtonHovered]         = ImVec4(0.32f, 0.26f, 0.48f, 1.00f);
    colors[ImGuiCol_ButtonActive]          = ImVec4(0.45f, 0.35f, 0.62f, 1.00f);
    colors[ImGuiCol_Header]                = ImVec4(0.20f, 0.15f, 0.30f, 1.00f);
    colors[ImGuiCol_HeaderHovered]         = ImVec4(0.30f, 0.22f, 0.45f, 1.00f);
    colors[ImGuiCol_HeaderActive]          = ImVec4(0.40f, 0.30f, 0.55f, 1.00f);
    colors[ImGuiCol_Separator]             = ImVec4(0.45f, 0.35f, 0.65f, 0.70f);

    // Style rounded & padding elegan
    style.WindowRounding    = 14.0f;
    style.ChildRounding     = 12.0f;
    style.FrameRounding     = 8.0f;
    style.PopupRounding     = 10.0f;
    style.GrabRounding      = 8.0f;
    style.ScrollbarRounding = 12.0f;
    style.WindowPadding     = ImVec2(18, 14);
    style.FramePadding      = ImVec2(10, 8);
    style.ItemSpacing       = ImVec2(12, 10);
    style.WindowTitleAlign  = ImVec2(0.5f, 0.5f);
    style.WindowBorderSize  = 1.5f;
    style.FrameBorderSize   = 1.0f;
    style.AntiAliasedLines  = true;
    style.AntiAliasedFill   = true;

    // Font modern dan tebal
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 34.0f;
    io.Fonts->AddFontFromMemoryTTF(Roboto_Regular, sizeof(Roboto_Regular), 34.0f, &font_cfg);

    font_cfg.SizePixels = 26.0f;
    io.Fonts->AddFontFromMemoryTTF(Roboto_Regular, sizeof(Roboto_Regular), 26.0f, &font_cfg);

    ImGui_ImplOpenGL3_Init("#version 100");
}

bool ImGuiOK = false;
static bool g_ShowMenu = false;
void DrawLogo() {
    if (!ImGuiOK) return;

    ImGui::SetNextWindowPos(ImVec2(100, 100), ImGuiCond_FirstUseEver);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoSavedSettings |
                             ImGuiWindowFlags_AlwaysAutoResize |
                             ImGuiWindowFlags_NoTitleBar |
                             ImGuiWindowFlags_NoBackground |
                             ImGuiWindowFlags_NoFocusOnAppearing;
    ImGui::Begin("FloatingLogo", nullptr, flags);

    float size = 78.0f;
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 center = ImVec2(pos.x + size/2, pos.y + size/2);
    float radius = size/2;
    static float time = 0.0f;
    time += ImGui::GetIO().DeltaTime * 2.5f;
    float pulse = sinf(time) * 0.06f + 0.94f; 
    draw->AddCircleFilled(center, radius * pulse + 6.0f, IM_COL32(90, 50, 150, 120), 64);
    draw->AddCircleFilled(center, radius * pulse + 3.0f, IM_COL32(150, 110, 40, 160), 64);

    ImGui::InvisibleButton("VIPBtn", ImVec2(size, size));
    bool hovered = ImGui::IsItemHovered();
    bool active = ImGui::IsItemActive();

    ImU32 col1 = hovered ? IM_COL32(210, 160, 40, 255) : IM_COL32(190, 140, 20, 255);
    ImU32 col2 = hovered ? IM_COL32(130, 70, 190, 255) : IM_COL32(110, 50, 170, 255);
    draw->AddCircleFilled(center, radius, col1, 32);
    draw->AddCircleFilled(center, radius * 0.85f, col2, 32);

    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
    ImVec2 textSize = ImGui::CalcTextSize("VIP");
    ImVec2 textPos = ImVec2(center.x - textSize.x/2, center.y - textSize.y/2);
    draw->AddText(textPos, IM_COL32(255, 255, 255, 255), "VIP");
    ImGui::PopFont();
    static bool dragging = false;
    if (active && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
        dragging = true;
        ImVec2 delta = ImGui::GetIO().MouseDelta;
        ImVec2 wpos = ImGui::GetWindowPos();
        ImGui::SetWindowPos(ImVec2(wpos.x + delta.x, wpos.y + delta.y));
    }
    if (ImGui::IsItemDeactivated()) {
        if (!dragging && hovered) g_ShowMenu = !g_ShowMenu;
        dragging = false;
    }

    ImGui::End();
    ImGui::PopStyleVar();
}

static void ToggleButton(const char* label, bool* v) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    ImVec2 pos = window->DC.CursorPos;
    float height = ImGui::GetTextLineHeightWithSpacing();
    float width = height * 1.8f;
    float radius = height * 0.50f;

    ImGui::InvisibleButton(label, ImVec2(width, height));
    bool active = ImGui::IsItemHovered() || *v;
    ImU32 bg = *v ? IM_COL32(200, 155, 30, 255) : IM_COL32(50, 50, 65, 255);
    ImU32 knob = IM_COL32(255, 255, 255, 255);
    if (ImGui::IsItemClicked()) *v = !*v;

    ImDrawList* draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), bg, height * 0.5f);
    float knobX = *v ? pos.x + width - radius - 2.0f : pos.x + radius + 2.0f;
    draw->AddCircleFilled(ImVec2(knobX, pos.y + radius), radius - 2.0f, knob);
    ImGui::SameLine();
    ImGui::TextUnformatted(label);
}
void DrawMenu() {
    if (!g_ShowMenu) return;

    ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f,
                                   ImGui::GetIO().DisplaySize.y * 0.5f),
                            ImGuiCond_Once, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(420, 380), ImGuiCond_FirstUseEver);ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(24, 20));
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse; 
    ImGui::Begin("KTVIP", &g_ShowMenu, flags);
    ImGui::PopStyleVar();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 wpos = ImGui::GetWindowPos();
    ImVec2 wsize = ImGui::GetWindowSize();
    ImVec2 headerStart = wpos;
    ImVec2 headerEnd = ImVec2(wpos.x + wsize.x, wpos.y + 55);

    draw->AddRectFilledMultiColor(headerStart, headerEnd,
        IM_COL32(140, 70, 190, 200), IM_COL32(200, 140, 40, 200),
        IM_COL32(200, 140, 40, 200), IM_COL32(140, 70, 190, 200));
    draw->AddLine(ImVec2(headerStart.x, headerEnd.y), ImVec2(headerEnd.x, headerEnd.y),
                  IM_COL32(255, 200, 40, 255), 2.5f);

    ImGui::SetCursorPosY(12);
    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
    ImVec2 titleSize = ImGui::CalcTextSize(" KTVIP ");
    ImGui::SetCursorPosX((wsize.x - titleSize.x) * 0.5f);
    ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "KTVIP ");
    ImGui::PopFont();
    ImGui::SetCursorPosY(60);

    ImGui::BeginChild("Content", ImVec2(0, 0), true, ImGuiWindowFlags_NoScrollbar);
    ImGui::Spacing();
    ImGui::TextColored(ImVec4(0.9f, 0.7f, 0.1f, 1.0f), " [ ESP Settings ]");
    ImGui::Separator();
    ImGui::Spacing();

    ToggleButton("Enable Line ESP", &Config.ESP.Line);
    ImGui::Spacing();
    ToggleButton("Enable Box ESP", &Config.ESP.Box);
    ImGui::Spacing();
    ToggleButton("Enable Health Bar", &Config.ESP.Health);
    ImGui::Spacing();
    ToggleButton("Enable Distance Info", &Config.ESP.Distance);

    ImGui::Spacing();
    ImGui::EndChild();
    ImGui::End();
}
inline EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
inline EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {

  eglQuerySurface(dpy, surface, EGL_WIDTH, &g_GlWidth);
  eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_GlHeight);
  
  static bool should_clear_mouse_pos = false;

  if (!g_IsSetup) {
    prevWidth = g_GlWidth;
    prevHeight = g_GlHeight;
    SetupImgui();
    g_IsSetup = true;
  }
  
  ImGuiIO &io = ImGui::GetIO();
  ImGui_ImplOpenGL3_NewFrame();
  ImGui_ImplAndroid_NewFrame(g_GlWidth, g_GlHeight);
  ImGui::NewFrame();
  
  if (ImGuiOK) {
    InitOffsetsLazily();
    DrawESP(g_GlWidth, g_GlHeight);

    if (O_get_touchCount && O_GetTouch) {
        int (*TouchCount)(void*) = (int (*)(void*)) O_get_touchCount;
        int touchCount = TouchCount(nullptr);
        
        if (touchCount > 0) {
            auto GetTouch = (UnityEngine_Touch_Fields (*)(int)) O_GetTouch;
            UnityEngine_Touch_Fields touch = GetTouch(0);
            float reverseY = io.DisplaySize.y - touch.m_Position.fields.y;

            switch (touch.m_Phase) {
              case TouchPhase::Began:
              case TouchPhase::Stationary:
              io.MousePos = ImVec2(touch.m_Position.fields.x, reverseY);
              io.MouseDown[0] = true;
              break;
              case TouchPhase::Ended:
              case TouchPhase::Canceled:
              io.MouseDown[0] = false;
              should_clear_mouse_pos = true;
              break;
              case TouchPhase::Moved:
              io.MousePos = ImVec2(touch.m_Position.fields.x, reverseY);
              break;
              default:
              break;
            }
        } else {
            io.MouseDown[0] = false;
        }
    }
  }
  
  DrawLogo();
  DrawMenu();
  
  ImGui::Render();
  ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
  ImGui::EndFrame();
  
  if (should_clear_mouse_pos) {
    io.MousePos = ImVec2(-1, -1);
    should_clear_mouse_pos = false;
  }

  return old_eglSwapBuffers(dpy, surface);
}

typedef unsigned long DWORD;
static uintptr_t libBase;

pid_t get_pid_by_name(const char* process_name) {
  DIR* proc_dir = opendir("/proc");
  if (!proc_dir) return -1;

  struct dirent* entry;
  while ((entry = readdir(proc_dir)) != NULL) {
    if (entry->d_type != DT_DIR) continue;

    pid_t pid = atoi(entry->d_name);
    if (pid <= 0) continue;

    char cmdline_path[256];
    snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%d/cmdline", pid);

    FILE* fp = fopen(cmdline_path, "r");
    if (!fp) continue;

    char cmdline[256];
    fgets(cmdline, sizeof(cmdline), fp);
    fclose(fp);

    if (strstr(cmdline, process_name)) {
      closedir(proc_dir);
      return pid;
    }
  }
  closedir(proc_dir);
  return -1;
}

inline void hack_injec();
inline void StartGUI() {
  void *ptr_eglSwapBuffer = DobbySymbolResolver("/system/lib/libEGL.so", "eglSwapBuffers");
  if (NULL != ptr_eglSwapBuffer) {
    DobbyHook((void *)ptr_eglSwapBuffer, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
    hack_injec();
  }
}
ProcMap unityMap, il2cppMap;

void hack() {}

void hack_injec() {
    int maxAttempts = 15;
    int attempts = 0;
    
    while (!unityMap.isValid() && attempts < maxAttempts) {
        unityMap = KittyMemory::getLibraryBaseMap("libcsharp.so");
        il2cppMap = KittyMemory::getLibraryBaseMap("libcsharp.so");
        sleep(5);
        attempts++;
    }
    
    if (attempts >= maxAttempts) return;
    
    sleep(2);
    Il2CppAttach("liblogic.so");
    ImGuiOK = true; 
}
void hack_thread(pid_t pid) {
  StartGUI();
  while(pid == -1) {
    pid = get_pid_by_name(packageName);
    sleep(1);
  }
}
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void * reserved) {
  JNIEnv *env;
  vm->GetEnv((void **) &env, JNI_VERSION_1_6);
  return JNI_VERSION_1_6;
}
__attribute__((constructor))
void lib_main() {
  std::thread thread_hack(hack_thread, get_pid_by_name(packageName));
  thread_hack.detach();
}