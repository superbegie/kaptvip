#pragma once
#include "Struct/UseFull.h"
#include "AutoUpdate/Tools/Call_Tools.h" // 
struct UnityEngine_Vector2_Fields { float x; float y; };
struct UnityEngine_Vector2_o { UnityEngine_Vector2_Fields fields; };
enum TouchPhase { Began = 0, Moved = 1, Stationary = 2, Ended = 3, Canceled = 4 };
struct UnityEngine_Touch_Fields {
    int32_t m_FingerId;
    struct UnityEngine_Vector2_o m_Position;
    struct UnityEngine_Vector2_o m_RawPosition;
    struct UnityEngine_Vector2_o m_PositionDelta;
    float m_TimeDelta;
    int32_t m_TapCount;
    int32_t m_Phase;
    int32_t m_Type;
    float m_Pressure;
    float m_maximumPossiblePressure;
    float m_Radius;
    float m_RadiusVariance;
    float m_AltitudeAngle;
    float m_AzimuthAngle;
};
inline uintptr_t O_get_main = 0;
inline uintptr_t O_WorldToScreenPoint = 0;
inline uintptr_t O_get_touchCount = 0;
inline uintptr_t O_GetTouch = 0;

inline uintptr_t O_ListPlayer = 0;
inline uintptr_t O_Local = 0;
inline uintptr_t O_Team = 0;
inline uintptr_t O_Die = 0;
inline uintptr_t O_Position = 0;
inline uintptr_t O_Hp = 0;
inline uintptr_t O_HpMax = 0;

inline void InitOffsetsLazily() {
    if (O_get_main == 0) O_get_main = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"), OBFUSCATE("get_main"), 0);
    if (O_WorldToScreenPoint == 0) O_WorldToScreenPoint = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"), OBFUSCATE("WorldToScreenPoint"), 1);
    if (O_get_touchCount == 0) O_get_touchCount = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("get_touchCount"), 0);
    if (O_GetTouch == 0) O_GetTouch = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("GetTouch"), 1);

    if (O_ListPlayer == 0) O_ListPlayer = Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("BattleManager"), OBFUSCATE("m_ShowPlayers"));
    if (O_Local == 0) O_Local = Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("BattleManager"), OBFUSCATE("m_LocalPlayerShow"));
    if (O_Team == 0) O_Team = Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ShowEntity"), OBFUSCATE("m_bSameCampType"));
    if (O_Die == 0) O_Die = Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ShowEntity"), OBFUSCATE("m_bDeath"));
    if (O_Position == 0) O_Position = Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ShowEntity"), OBFUSCATE("m_vCachePosition"));
    if (O_Hp == 0) O_Hp = Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ShowEntity"), OBFUSCATE("m_Hp"));
    if (O_HpMax == 0) O_HpMax = Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ShowEntity"), OBFUSCATE("m_HpMax"));
}
static void *Curent_Match() {
    void *battleManagerInstance = nullptr;
    Il2CppGetStaticFieldValue(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("BattleManager"), OBFUSCATE("Instance"), &battleManagerInstance);
    return battleManagerInstance;
}
static void *Camera_main() {
    if (O_get_main == 0) return nullptr;
    return reinterpret_cast<void *(__fastcall *)()>(O_get_main)();
}
static Vector3 WorldToScreenPoint(void *camera, Vector3 worldPos) {
    if (O_WorldToScreenPoint == 0 || !camera || !Tools::IsPtrValid(camera)) return Vector3::zero();
    
    Vector3 (*_WorldToScreenPoint)(void*, Vector3) = (Vector3 (*)(void*, Vector3))(O_WorldToScreenPoint);
    return _WorldToScreenPoint(camera, worldPos);
}