#pragma once

#include "Class.h"
#include "Rect.h" 
#include "Drawing.h"
#include "main.h"
#include <imgui.h>
#include "Unity/unity.h"
#include <string>
#include <vector>
#include <chrono> 

struct PlayerData {
    Vector3 position;
    int hp = 0;
    int hpMax = 0;
    bool isDead = false;
    bool sameTeam = false;
};
static std::vector<PlayerData> g_PlayerSnapshot;
static Vector3 g_SelfPosition = Vector3::zero();
static uint64_t g_LastSnapshotTime = 0;

void DrawCornerBox(ImDrawList* draw, float x, float y, float width, float height, ImU32 color, float thickness) {
    float cornerLength = width * 0.3f;
    draw->AddLine(ImVec2(x, y), ImVec2(x + cornerLength, y), color, thickness);
    draw->AddLine(ImVec2(x + width - cornerLength, y), ImVec2(x + width, y), color, thickness);
    draw->AddLine(ImVec2(x + width, y), ImVec2(x + width, y + cornerLength), color, thickness);
    draw->AddLine(ImVec2(x + width, y + height - cornerLength), ImVec2(x + width, y + height), color, thickness);
    draw->AddLine(ImVec2(x + width, y + height), ImVec2(x + width - cornerLength, y + height), color, thickness);
    draw->AddLine(ImVec2(x + cornerLength, y + height), ImVec2(x, y + height), color, thickness);
    draw->AddLine(ImVec2(x, y + height), ImVec2(x, y + height - cornerLength), color, thickness);
    draw->AddLine(ImVec2(x, y + cornerLength), ImVec2(x, y), color, thickness);
}

template<typename T>
bool SafeRead(void* addr, T& out) {
    return Tools::PVM_ReadAddr(addr, &out, sizeof(T));
}

inline void UpdatePlayerSnapshot() {
    g_PlayerSnapshot.clear();

    void *current_Match = Curent_Match();
    if (!current_Match || !Tools::IsPtrValid(current_Match)) return;

    void* local_player = nullptr;
    if (!SafeRead((void*)((uintptr_t)current_Match + O_Local), local_player)) return;
    if (!local_player || !Tools::IsPtrValid(local_player)) return;

    SafeRead((void*)((uintptr_t)local_player + O_Position), g_SelfPosition);

    monoList<void*>* players = nullptr;
    if (!SafeRead((void*)((uintptr_t)current_Match + O_ListPlayer), players)) return;
    if (!players || !Tools::IsPtrValid(players)) return;

    int size = 0;
    SafeRead((void*)((uintptr_t)players + offsetof(monoList<void*>, size)), size);
    if (size <= 0 || size > 80) return;

    void** items = nullptr;
    if (!SafeRead((void*)((uintptr_t)players + offsetof(monoList<void*>, items)), items)) return;
    if (!items || !Tools::IsPtrValid(items)) return;

    bool localTeam = false;
    SafeRead((void*)((uintptr_t)local_player + O_Team), localTeam);

    uintptr_t arrayDataOffset = 0x20;

    for(int i = 0; i < size; i++) {
        void* enemy = nullptr;
        
        if (!SafeRead((void*)((uintptr_t)items + arrayDataOffset + (i * sizeof(void*))), enemy)) continue;
        if (!enemy || !Tools::IsPtrValid(enemy) || enemy == local_player) continue;

        PlayerData pd{};
        SafeRead((void*)((uintptr_t)enemy + O_Position), pd.position);
        SafeRead((void*)((uintptr_t)enemy + O_Hp), pd.hp);
        SafeRead((void*)((uintptr_t)enemy + O_HpMax), pd.hpMax);
        SafeRead((void*)((uintptr_t)enemy + O_Die), pd.isDead);
        SafeRead((void*)((uintptr_t)enemy + O_Team), pd.sameTeam);

        if (pd.isDead || pd.sameTeam) continue;
        
        g_PlayerSnapshot.push_back(pd);
    }
}

inline void DrawESP(float screenWidth, float screenHeight) {
    if (!Config.ESP.Line && !Config.ESP.Box && !Config.ESP.Health && !Config.ESP.Distance) return;

    InitOffsetsLazily();
    uint64_t now = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()
    ).count();

    if (now - g_LastSnapshotTime >= 16) {
        UpdatePlayerSnapshot();
        g_LastSnapshotTime = now;
    }

    if (g_PlayerSnapshot.empty()) return;

    ImDrawList* draw = ImGui::GetBackgroundDrawList();
    if (!draw) return;

    void *camera = Camera_main();
    if (!camera || !Tools::IsPtrValid(camera)) return;

    Vector3 screenSelfPos = WorldToScreenPoint(camera, g_SelfPosition);

    for(const auto& pd : g_PlayerSnapshot) {
        Vector3 screenFootPos = WorldToScreenPoint(camera, pd.position);
        if (screenFootPos.z < 0.1f) continue;

        Vector3 headPos = pd.position + Vector3(0, 1.7f, 0);
        Vector3 screenHeadPos = WorldToScreenPoint(camera, headPos);
        if (screenHeadPos.z < 0.1f) continue;

        float boxHeight = fabs(screenHeadPos.y - screenFootPos.y);
        float boxWidth = boxHeight * 0.45f;

        float x = screenHeadPos.x - boxWidth / 2;
        float y = screenHeight - screenHeadPos.y;

        ImU32 espColor = IM_COL32(255, 255, 255, 255);
        ImU32 textShadowColor = IM_COL32(0, 0, 0, 255);

        float distance = Vector3::Distance(g_SelfPosition, pd.position);

        if (Config.ESP.Line) {
            ImVec2 startPos = (screenSelfPos.z > 0.1f) ? 
                ImVec2(screenSelfPos.x, screenHeight - screenSelfPos.y) : 
                ImVec2(screenWidth / 2, screenHeight);
            draw->AddLine(startPos, ImVec2(x + boxWidth / 2, y + boxHeight), espColor, 2.0f);
        }

        if (Config.ESP.Box) {
            DrawCornerBox(draw, x, y, boxWidth, boxHeight, espColor, 2.0f);
        }
       if (Config.ESP.Health) {
            float hpRatio = (pd.hpMax > 0) ? (float)pd.hp / pd.hpMax : 0.0f;
            if (hpRatio > 1.0f) hpRatio = 1.0f;
            if (hpRatio < 0.0f) hpRatio = 0.0f;

            float footX = x + boxWidth / 2.0f;
            float footY = y + boxHeight;

            ImVec2 lineStart = ImVec2(footX + 40.0f, footY - 30.0f);
            ImVec2 lineEnd   = ImVec2(lineStart.x + 160.0f, lineStart.y);

            ImVec2 healthStart = ImVec2(lineStart.x, lineStart.y - 20.0f);
            ImVec2 healthEnd   = ImVec2(lineEnd.x, lineEnd.y - 5.0f);
            float fillWidth    = (healthEnd.x - healthStart.x) * hpRatio;

            draw->AddLine(ImVec2(footX, footY), lineStart, IM_COL32(255, 255, 255, 255), 1.5f);
            draw->AddLine(lineStart, lineEnd, IM_COL32(255, 255, 255, 155), 1.5f);
            draw->AddRectFilled(healthStart, ImVec2(healthStart.x + fillWidth, healthEnd.y), IM_COL32(225, 0, 0, 255), 7.0f);
            draw->AddRect(healthStart, healthEnd, IM_COL32(0, 0, 0, 255), 7.0f, 0, 1.5f);
        }

        if (Config.ESP.Distance) {
            std::string info = "[" + std::to_string(static_cast<int>(distance)) + "m]";
            ImVec2 textSize = ImGui::CalcTextSize(info.c_str());
            float textX = x + (boxWidth / 2) - (textSize.x / 2);
            float textY = y + boxHeight + 4;
            
            draw->AddText(ImVec2(textX + 1, textY + 1), textShadowColor, info.c_str());
            draw->AddText(ImVec2(textX, textY), IM_COL32(0, 255, 255, 255), info.c_str());
        }
    }
}