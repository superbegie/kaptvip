// Color.h - TAMBAHKAN FUNGSI INI
#pragma once
#include <cmath>

struct Color {
    union {
        struct {
            float r, g, b, a;
        };
        float data[4];
    };
    
    Color() { SetColor(0, 0, 0, 255); }
    Color(float r, float g, float b) { SetColor(r, g, b, 255); }
    Color(float r, float g, float b, float a) { SetColor(r, g, b, a); }
    
    void SetColor(float r1, float g1, float b1, float a1 = 255) {
        r = r1 / 255.0f;
        g = g1 / 255.0f;
        b = b1 / 255.0f;
        a = a1 / 255.0f;
    }
    
    // TAMBAHKAN FUNGSI INI
    ImU32 GetU32() const {
        return ImColor(r, g, b, a);
    }
    
    // TAMBAHKAN FUNGSI INI
    static Color FromHSB(float hue, float saturation, float brightness) {
        float h = hue == 1.0f ? 0 : hue * 6.0f;
        float f = h - (int)h;
        float p = brightness * (1.0f - saturation);
        float q = brightness * (1.0f - saturation * f);
        float t = brightness * (1.0f - saturation * (1.0f - f));
        
        if (h < 1) {
            return Color(brightness, t, p);
        } else if (h < 2) {
            return Color(q, brightness, p);
        } else if (h < 3) {
            return Color(p, brightness, t);
        } else if (h < 4) {
            return Color(p, q, brightness);
        } else if (h < 5) {
            return Color(t, p, brightness);
        } else {
            return Color(brightness, p, q);
        }
    }
    
    // Fungsi static colors yang sudah ada...
    static Color Black(float a = 255) { return Color(0, 0, 0, a); }
    static Color Red(float a = 255) { return Color(255, 0, 0, a); }
    static Color Green(float a = 255) { return Color(0, 255, 0, a); }
    static Color Blue(float a = 255) { return Color(0, 0, 255, a); }
    static Color White(float a = 255) { return Color(255, 255, 255, a); }
    // ... tambahkan lainnya sesuai kebutuhan
};